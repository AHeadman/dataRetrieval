### R code from vignette source 'dataRetrieval.Rnw'

###################################################
### code chunk number 1: openLibrary
###################################################
library(xtable)
options(continue=" ")
options(SweaveHooks=list(fig=function()
  par(mar=c(4.1,4.1,1.1,4.1),oma=c(0,0,0,0))))


###################################################
### code chunk number 2: tableParameterCodes
###################################################
pCode <- c('00060', '00065', '00010','00045','00400')
shortName <- c("Discharge [cfs]","Gage height [ft]","Temperature [C]", "Precipitation [in]", "pH")

data.df <- data.frame(pCode, shortName, stringsAsFactors=FALSE)

data.table <- xtable(data.df,
                     caption="Commonly found USGS Parameter Codes")
print(data.table, 
      caption.placement="top")


###################################################
### code chunk number 3: tableStatCodes
###################################################
StatCode <- c('00001', '00002', '00003','00008')
shortName <- c("Maximum","Minimum","Mean", "Median")

data.df <- data.frame(StatCode, shortName, stringsAsFactors=FALSE)

data.table <- xtable(data.df,
                     caption="Commonly found USGS Stat Codes")
print(data.table, 
      caption.placement="top")


###################################################
### code chunk number 4: getSite
###################################################
library(dataRetrieval)
# Site ID for Choptank River near Greensboro, MD
siteNumber <- "01491000" 
ChoptankInfo <- getSiteFileData(siteNumber)


###################################################
### code chunk number 5: tableSiteInfo
###################################################

infoDF <- data.frame(ColumnNames=names(ChoptankInfo[1:11]),ColumnNames=names(ChoptankInfo[12:22]),
                     ColumnNames=names(ChoptankInfo[23:33]),ColumnNames=names(c(ChoptankInfo[34:43],"")))
data.table <- xtable(infoDF,
                     caption="Column names in ChoptankInfo")
print(data.table, caption.placement="top",floating="FALSE",latex.environments=NULL)


###################################################
### code chunk number 6: siteNames
###################################################
ChoptankInfo$station.nm


###################################################
### code chunk number 7: getSite
###################################################
# Using defaults:
parameterCd <- "00618" 
parameterINFO <- getParameterInfo(parameterCd)
colnames(parameterINFO)


###################################################
### code chunk number 8: siteNames
###################################################
parameterINFO$parameter_nm


###################################################
### code chunk number 9: getNWISDaily
###################################################
# Using defaults:
siteNumber <- "01491000"
parameterCd <- "00060"  # Discharge in cubic feet per second
startDate <- ""  # Will request earliest date
endDate <- "" # Will request latest date

discharge <- retrieveNWISData(siteNumber, parameterCd, startDate, endDate)


###################################################
### code chunk number 10: dischargeData
###################################################
head(discharge)


###################################################
### code chunk number 11: getNWIStemperature
###################################################
# Using defaults:
siteNumber <- "01491000" 
parameterCd <- "00010,00060"  # Temperature and discharge
statCd <- "00001,00003"  # Mean and maximum
startDate <- "2012-01-01"
endDate <- "2012-06-30"

temperatureAndFlow <- retrieveNWISData(siteNumber, parameterCd, 
                  startDate, endDate, StatCd=statCd,interactive=FALSE)


###################################################
### code chunk number 12: getNWIStemperaturePlot
###################################################

with(temperatureAndFlow, plot(
  datetime, X01_00010_00003,
  xlab="Date",ylab="Temperature [C]"
  ))
par(new=TRUE)
with(temperatureAndFlow, plot(
  datetime, X02_00060_00003,
  col="red",type="l",xaxt="n",yaxt="n",xlab="",ylab="",axes=FALSE
  ))
axis(4,col="red",col.axis="red")
mtext("Discharge [cfs]",side=4,line=3,col="red")


###################################################
### code chunk number 13: fig1
###################################################

with(temperatureAndFlow, plot(
  datetime, X01_00010_00003,
  xlab="Date",ylab="Temperature [C]"
  ))
par(new=TRUE)
with(temperatureAndFlow, plot(
  datetime, X02_00060_00003,
  col="red",type="l",xaxt="n",yaxt="n",xlab="",ylab="",axes=FALSE
  ))
axis(4,col="red",col.axis="red")
mtext("Discharge [cfs]",side=4,line=3,col="red")


###################################################
### code chunk number 14: getNWISUnit
###################################################
siteNumber <- "01491000" # Site ID for Choptank River near Greensboro, MD
parameterCd <- "00060"  # Discharge in cubic feet per second
startDate <- as.character(Sys.Date()-1) # Yesterday 
  # (or, the day before the dataRetrieval package was built)
endDate <- as.character(Sys.Date()) # Today 
  # (or, the day the dataRetrieval package was built)

dischargeToday <- retrieveUnitNWISData(siteNumber, parameterCd, 
        startDate, endDate)


###################################################
### code chunk number 15: dischargeData
###################################################
head(dischargeToday)


###################################################
### code chunk number 16: getNWISUnit
###################################################
with(dischargeToday, plot(
  datetime, X02_00060,
  ylab="Discharge [cfs]",xlab=""
  ))


###################################################
### code chunk number 17: fig2
###################################################
with(dischargeToday, plot(
  datetime, X02_00060,
  ylab="Discharge [cfs]",xlab=""
  ))


###################################################
### code chunk number 18: getQW
###################################################
siteNumber <- "01491000" 
# Dissolved Nitrate parameter codes:
parameterCd <- "00618;71851"  
startDate <- "1964-06-11"
endDate <- "2012-12-18"

dissolvedNitrate <- getRawQWData(siteNumber, parameterCd, 
      startDate, endDate)


###################################################
### code chunk number 19: colNamesQW
###################################################
infoDF <- data.frame(ColumnNames=names(dissolvedNitrate[1:31]),ColumnNames=names(dissolvedNitrate[32:62]))
data.table <- xtable(infoDF,
                     caption="Column names in dissolvedNitrate")
print(data.table, caption.placement="top",floating="FALSE",latex.environments=NULL)


###################################################
### code chunk number 20: getQWData
###################################################
dissolvedNitrateSimple <- getQWData(siteNumber, parameterCd, 
        startDate, endDate)
names(dissolvedNitrateSimple)


###################################################
### code chunk number 21: getQWtemperaturePlot
###################################################
with(dissolvedNitrateSimple, plot(
  dateTime, value.00618,
  xlab="Date",ylab = paste(parameterINFO$srsname,
      "[",parameterINFO$parameter_units,"]")
  ))


###################################################
### code chunk number 22: fig3
###################################################
with(dissolvedNitrateSimple, plot(
  dateTime, value.00618,
  xlab="Date",ylab = paste(parameterINFO$srsname,
      "[",parameterINFO$parameter_units,"]")
  ))


###################################################
### code chunk number 23: getQWData
###################################################
specificCond <- getWQPData('WIDNR_WQX-10032762', 
        'Specific conductance', '', '')
head(specificCond)


###################################################
### code chunk number 24: firstExample
###################################################
siteNumber <- "01491000"
parameterCd <- "00631"  # Nitrate
startDate <- "1964-01-01"
endDate <- "2013-01-01"

Daily <- getDVData(siteNumber, "00060", startDate, endDate,interactive=FALSE)
summary(Daily)


###################################################
### code chunk number 25: colNamesDaily
###################################################
ColumnName <- c("Date", "Q", "Julian","Month","Day","DecYear","MonthSeq","Qualifier","i","LogQ","Q7","Q30")
Type <- c("Date", "number", "number","integer","integer","number","integer","string","integer","number","number","number")
Description <- c("Date", "Discharge in cms", "Number of days since January 1, 1850", "Month of the year [1-12]", "Day of the year [1-366]", "Decimal year", "Number of months since January 1, 1850", "Qualifing code", "Index", "Natural logarithm of Q", "7 day running average of Q", "30 running average of Q")

DF <- data.frame(ColumnName,Type,Description)

data.table <- xtable(DF,
                     caption="Daily dataframe")
print(data.table, caption.placement="top",floating="FALSE",latex.environments=NULL)


###################################################
### code chunk number 26: secondExample
###################################################
Sample <-getSampleData(siteNumber,parameterCd,
      startDate, endDate,interactive=FALSE)
summary(Sample)


###################################################
### code chunk number 27: colNamesQW
###################################################
ColumnName <- c("Date", "ConcLow", "ConcHigh", "Uncen", "ConcAve", "Julian","Month","Day","DecYear","MonthSeq","SinDY","CosDY","Q","LogQ")
Type <- c("Date", "number","number","integer","number", "number","integer","integer","number","integer","number","number","number","number")
Description <- c("Date", "Lower limit of concentration", "Upper limit of concentration", "Uncensored data (1=true, 0=false)", "Average concentration","Number of days since January 1, 1850", "Month of the year [1-12]", "Day of the year [1-366]", "Decimal year", "Number of months since January 1, 1850", "Sine of ...", "Cosine of ...", "Discharge in cms", "Natural logarithm of flow")

DF <- data.frame(ColumnName,Type,Description)

data.table <- xtable(DF,
                     caption="Sample dataframe")
print(data.table, caption.placement="top",floating="FALSE",latex.environments=NULL)


###################################################
### code chunk number 28: ThirdExample
###################################################
INFO <-getMetaData(siteNumber,parameterCd, interactive=FALSE)


###################################################
### code chunk number 29: colNamesQW
###################################################
infoDF <- data.frame(ColumnNames=names(INFO[1:21]),ColumnNames=names(c(INFO[22:41],"")))
data.table <- xtable(infoDF,
                     caption="Column names in the INFO dataframe")
print(data.table, caption.placement="top",floating="FALSE",latex.environments=NULL)


###################################################
### code chunk number 30: openDaily
###################################################
fileName <- "ChoptankRiverFlow.txt"
filePath <-  "~/RData/"
Daily <- getDailyDataFromFile(filePath,fileName,separator="\t",interactive=FALSE)
head(Daily)


###################################################
### code chunk number 31: openSample
###################################################
fileName <- "ChoptankRiverNitrate.csv"
filePath <-  "~/RData/"
Sample <- getSampleDataFromFile(filePath,fileName,separator=";",interactive=FALSE)
head(Sample)


###################################################
### code chunk number 32: installFromWD (eval = FALSE)
###################################################
## install.packages("dataRetrieval_1.2.1.tar.gz", 
##                  repos=NULL, type="source")


###################################################
### code chunk number 33: installFromFile (eval = FALSE)
###################################################
## install.packages(
##   "C:/RPackages/Statistics/dataRetrieval_1.2.1.tar.gz", 
##   repos=NULL, type="source")


###################################################
### code chunk number 34: maxExample (eval = FALSE)
###################################################
## install.packages(
##   "/Users/userA/RPackages/Statistic/dataRetrieval_1.2.1.tar.gz", 
##   repos=NULL, type="source")


###################################################
### code chunk number 35: openLibraryTest (eval = FALSE)
###################################################
## library(dataRetrieval)


###################################################
### code chunk number 36: gitInstal (eval = FALSE)
###################################################
## library(devtools)
## install_github("dataRetrieval", "USGS-R")


###################################################
### code chunk number 37: openLibrary (eval = FALSE)
###################################################
## library(dataRetrieval)


