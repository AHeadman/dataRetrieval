# Build the package:
library(devtools)
#Make sure these are in NAMESPACE:
export(formatCheckDate)
export(checkStartEndDate)
export(dateFormatCheck)
export(formatCheckParameterCd)
export(formatCheckSiteNumber)

setwd("D:/LADData/RCode/")
load_all("dataRetrieval/",reset = TRUE)
setwd("D:/LADData/RCode/dataRetrieval")
document()
export(formatCheckDate)
export(checkStartEndDate)
export(dateFormatCheck)
export(formatCheckParameterCd)
export(formatCheckSiteNumber)
check() 
#Add hidden functions:
export(formatCheckDate)
export(checkStartEndDate)
export(dateFormatCheck)
export(formatCheckParameterCd)
export(formatCheckSiteNumber)

# run_examples()
# test()   #Assumes testthat type tests in GLRI/inst/tests
setwd("D:/LADData/RCode/")
load_all("dataRetrieval/",reset = TRUE)
# build_win("dataRetrieval")
build("dataRetrieval")
install("dataRetrieval")